// -*- c++ -*-

#include "ns3/network-module.h"

using namespace ns3;

namespace 
{
void __foo ()
{
  static SequenceNumber32 a;
  static SequenceNumber16 b;
}

}

